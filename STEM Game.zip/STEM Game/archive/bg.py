import pygame
import sys
import pygame.sprite as sprite

theClock = pygame.time.Clock()

background = pygame.image.load('images/basemap.png')

background_size = background.get_size()
background_rect = background.get_rect()
screen_width = 700
screen_height = 500
screen = pygame.display.set_mode([screen_width, screen_height])
w,h = background_size
x = 0
y = 0

running = True

while running:
    screen.blit(background,background_rect)
    pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    y -= 5
    screen.blit(background,(x,y))
    if y > h:
        y = -h
    pygame.display.flip()
    pygame.display.update()
    theClock.tick(10)
