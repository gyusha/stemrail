import pygame, sys
from pygame.locals import *
import datetime
from itertools import chain
import eztext

###############

class Window:
    def __init__(self, screenWidth, screenHeight):
        global screen
        screen = pygame.display.set_mode((screenWidth,screenHeight),0,32)
        pygame.display.set_caption("Railway Engineer Game")
        self.w = screenWidth
        self.h = screenHeight

    def resize(self, screenWidth, screenHeight):
        global screen
        screen = pygame.display.set_mode((screenWidth,screenHeight),0,32)
        self.w = screenWidth
        self.h = screenHeight

class Mouse:
    def __init__(self):
        self.pos = (0,0)
        self.click = (0,0)
        self.single = False
        
    def update(self):
        self.pos = pygame.mouse.get_pos()
        new_click = pygame.mouse.get_pressed()
        if self.click[0] - new_click[0] == 1: self.single = True
        else: self.single = False
        self.click = new_click

class Menu_bg:
    def __init__(self, window, image):
        self.back = pygame.image.load(image).convert()
        self.w,self.h = self.back.get_size()
        window.resize(self.w, self.h)
        screen.blit(self.back, (0,0))

    def update(self):
        screen.blit(self.back, (0,0))

class Menu_button:
    def __init__(self, window, image, pos, function):
        self.window = window
        self.image = pygame.image.load(image)
        self.w,self.h = self.image.get_size()
        self.x = pos[0]
        self.y = pos[1]
        self.function = function
    
    def update(self):
        screen.blit(self.image, (self.x,self.y))
        if mouse.single and self.x < mouse.pos[0] < self.w+self.x and self.y < mouse.pos[1] < self.h+self.y:
            self.function.activate()

class Mconfirm:
    confirmed = False
    def activate():
        Mconfirm.confirmed = True
    
class Mchange:
    railways = ("Underground", "Metro", "Railways", "Subway", "S-Bahn", "Pendeltåg", "Transport", "Transport Authority")
    select = 0
    def activate():
        Mchange.select += 1
        if Mchange.select == len(Mchange.railways): Mchange.select = 0

class Map:
    def __init__(self, window, image, datum):
        self.back = pygame.image.load(image).convert()
        self.background_size = self.back.get_size()
        self.w,self.h = self.background_size
        self.window = window
        self.x = 0 #-self.w + window.w
        self.y = -self.h + window.h #0 - .5 * window.h
        self.offsetx = 0
        self.offsety = 0
        self.scrollrate = 0
        self.datum = datum
        self.follow = False

    def update(self):
        self.x = self.x + 2 * self.scrollrate
        self.y = self.y - 1 * self.scrollrate
        if self.follow:
            self.x = 0  + .5*self.window.w - 2*self.follow.z
            self.y = -self.h + .5*self.window.h + self.follow.z
        if self.x < self.window.w - self.w:
            self.x = self.window.w - self.w
        if self.x > 0:
            self.x = 0
        if self.y > -120: self.y = -120
        if self.y < -self.h + self.window.h:
            self.y = -self.h + self.window.h
        self.offsetx = 0 - self.x
        self.offsety = self.y - (-self.h + self.window.h)

        screen.blit(self.back, (self.x,self.y))
        
        self.scrollrate = 0
        if mouse.pos[0] >= self.window.w - 100 and mouse.pos[1] <= 100:
            self.scrollrate = -mouse.pos[1]/10
        elif mouse.pos[0] <= 100 and mouse.pos[1] >= self.window.h - 100:
            self.scrollrate = mouse.pos[0]/10

class UI_button:
    def __init__(self, window, image, ID, function, labeltext = False):
        self.window = window
        self.image = pygame.image.load(image)
        self.w,self.h = self.image.get_size()
        self.x = ID*100
        self.y = 0
        self.function = function
        self.labeltext = labeltext
    
    def update(self):
        screen.blit(self.image, (self.x,self.y))
        if mouse.single and mouse.pos[0] > self.x and mouse.pos[0] < self.w+self.x and mouse.pos[1] < self.h:
            self.labeltext = self.function.activate()
        if self.labeltext:
            label = gamefont.render(self.labeltext, 1, (255,255,0))
            screen.blit(label, (100,45))
    

class News:
    def __init__(self, tone, headline):
        self.tone = tone
        self.headline = headline

class City:
    def __init__(self, name, player, company):
        self.name = name
        self.player = player
        self.company = company
        self.population = 100000
        self.budget = 1000000
        self.year = 1

    def populate(self, rate):
        self.population += rate

    def revenue(self, amount):
        self.budget += amount

    def spend(self, amount):
        self.budget -= amount

    def newyear(self):
        self.year += 1
        self.budget = 1000000

class Train:
    ID = 0
    def __init__(self, localmap, model, length = 2):
        Train.ID += 1
        print(Train.ID)
        self.ID = Train.ID
        self.localmap = localmap
        self.model = model
        self.length = length
        self.sprite0 = pygame.image.load("images/t0_0.png")
        self.sprite1 = pygame.image.load("images/t0_1.png")
        self.w,self.h = self.sprite0.get_size()
        self.label = gamefont.render("Speed: 0 km/h", 1, (255,255,0))
        self.z = 0
        self.target = 0
        self.velocity = 0
        self.mass = 60000 * length
        self.Crr = .002
        self.dwell = 0
        self.not_crashed = True
        
    def update(self):
        if self.target > self.velocity: force = self.throttle()
        elif self.target < self.velocity: force = self.servicebrake()
        else: force = 0
        self.physics(force)
        self.z = self.z + self.velocity * .1
        
        if self.velocity > 0:
            self.dwell = 0
            labeltext = "Speed: " + str(round(self.velocity/.2778)) + " km/h"
        else:
            self.dwell += 10
            labeltext = "Dwell time: " + str(datetime.timedelta(seconds=self.dwell))
        self.label = gamefont.render(labeltext, 1, (255,255,0))
        
        if self.z > 1790: self.z = -110
        if mouse.click[1] == 1: print(self.velocity, self.z)
        #if mouse.click[2] == 1: print(self.z)
        screen.blit(self.sprite1, (self.localmap.datum[0] - self.localmap.offsetx + 2*self.z - self.w, self.localmap.datum[1] + self.localmap.offsety - self.z))
        screen.blit(self.sprite0, (self.localmap.datum[0] - self.localmap.offsetx + 2*(self.z - 34) - self.w, self.localmap.datum[1] + self.localmap.offsety - (self.z - 34)))
        if self.not_crashed: screen.blit(self.label, (self.localmap.datum[0] - self.localmap.offsetx + 2*(self.z) - self.w, self.localmap.datum[1] + self.localmap.offsety - (self.z) - 10))

    def targetspeed(self, targetkph):
        self.target = targetkph * .2778

    def throttle(self):
        if self.velocity < 10 * .2778: force = 40000
        elif (self.target - self.velocity) < 10 * .2778: force = 40000
        else: force = 70000
        return force

    def servicebrake(self):
        if self.velocity < 10 * .2778: force = -100000
        #elif (self.velocity - self.target) < 10 * .2778: force = -25000
        else: force = -75000
        return force

    def emergencybrake(self):
        pass

    def physics(self, force):
        frictionforce = self.Crr * self.mass * 9.81
        totalforce = force - frictionforce

        acceleration = totalforce / self.mass
        if mouse.click[1] == 1: print(acceleration)

        self.velocity = self.velocity + acceleration * .1
        if self.velocity < 0: self.velocity = 0

class Signal:
    ID = 0
    images = [False,False,False,False,False]
    images[2] = [pygame.image.load("images/s2r.png"),pygame.image.load("images/s2g.png")]
    images[3] = [pygame.image.load("images/s3r.png"),pygame.image.load("images/s3g.png"),pygame.image.load("images/s3y.png")]
    images[4] = [pygame.image.load("images/s4r.png"),pygame.image.load("images/s4g.png"),pygame.image.load("images/s4y.png"),pygame.image.load("images/s4yy.png")]
    def __init__(self, localmap, panel, z, signaltype):
        Signal.ID += 1
        self.ID = Signal.ID
        self.localmap = localmap
        self.panel = panel
        self.z = z
        self.signaltype = signaltype
        self.occupied = True
        self.aspect = 0
        self.next_aspect = 0

    def update(self):
        z_list = []
        for signal in signal_list:
            if signal: z_list.append((signal.z,signal.ID,signal.aspect))
        z_list = sorted(z_list)
        count = 0
        for signal in z_list:
            count += 1
            if signal[1] == self.ID:
                if count == 1: start = 2
                else: start = self.z*(self.panel.w/1790)
                if count == len(z_list):
                    zend = 1790
                    end = self.panel.w - 3
                    self.next_aspect = z_list[0][2]
                else:
                    zend = z_list[count][0] - 1
                    end = z_list[count][0]*(self.panel.w/1790) - 5
                    self.next_aspect = z_list[count][2]

        footprints = []
        self.occupied = False
        for train in train_list:
            if train:
                footprints.append((train.z, train.z - train.length * 34))
        for footprint in footprints:
            if self.z <= footprint[0] <= zend or self.z <= footprint[1] <= zend:
                self.occupied = True

        if self.occupied:
            self.aspect = 0
            colour = (255,0,0)
        else:
            if self.next_aspect == 0 and self.signaltype > 2: self.aspect = 2
            elif self.next_aspect == 2 and self.signaltype > 3: self.aspect = 3
            else: self.aspect = 1
            colour = (0,0,0)
                    
        screen.blit(Signal.images[self.signaltype][self.aspect], (self.localmap.datum[0] - self.localmap.offsetx + 2*self.z, self.localmap.datum[1] + self.localmap.offsety - self.z))
        pygame.draw.line(screen, colour, [self.panel.x+start,self.panel.y+42], [self.panel.x+end,self.panel.y+42], 7)

class Panel:
    def __init__(self, window, image):
        self.window = window
        self.image = pygame.image.load(image)
        self.w,self.h = self.image.get_size()
        self.x = self.window.w-self.w
        self.y = self.window.h-self.h
        self.colour = (255,0,0)

    def update(self):
        screen.blit(self.image, (self.x, self.y))

class Station:
    def __init__(self, ID, name, coachstop):
        self.ID = ID
        self.name = name
        self.coachstop = coachstop

class ATO:
    def __init__(self, train, stations_db):
        self.train = train
        self.stations_db = stations_db
        self.next_station = 0
        self.last_aspect = 1

    def update(self, stationskip = False):
        if self.train.not_crashed == False: return
        if self.train.dwell > 3000 or stationskip: #or self.train.z < self.stations_db[self.next_station].coachstop
            self.next_station += 1
        if self.next_station > 2:
            self.next_station = 0
        signal_sighted = self.human()
        if signal_sighted:
            self.last_aspect = signal_sighted[0]
        dtg = self.stations_db[self.next_station].coachstop - self.train.z
        if dtg < 2 and dtg >= 0:
            self.train.targetspeed(0)
        elif dtg < 620 and dtg >= 0:
            self.train.targetspeed(97*(dtg/620)+3)
        else: self.train.targetspeed(100)
        if self.last_aspect == 0: self.train.targetspeed(0)
        if self.last_aspect == 2 and self.train.target > 50: self.train.targetspeed(50)
        if self.last_aspect == 3 and self.train.target > 75: self.train.targetspeed(75)
        #if mouse.click[0] == 1: self.train.targetspeed(0)

    def human(self):
        z_list = []
        for signal in signal_list:
            if signal: z_list.append((signal.z,signal.ID))
        z_list = sorted(z_list)
        count = 0
        for signal in z_list:
            count += 1
            if self.train.z + 180 >= signal[0] > self.train.z:
                return (signal_list[signal[1]].aspect, signal[0] - self.train.z)
        return False

        footprints = []
        self.occupied = False
        for train in train_list:
            if train:
                footprints.append((train.z, train.z - train.length * 34))
        for footprint in footprints:
            if self.z <= footprint[0] <= zend or self.z <= footprint[1] <= zend:
                self.occupied = True

class CollisionDetection:
    def update():
        footprints = []
        for train in train_list:
            if train:
                footprints.append((round(train.z), round(train.z - train.length * 34), train.ID))
        for train1 in range(0,len(footprints)):
            for train2 in chain(range(0,train1), range(train1+1,len(footprints))):
                if footprints[train1][0] in range(footprints[train2][1],footprints[train2][0]):
                    if 0 < train_list[footprints[train1][2]].z < 1769:
                        ctrain1 = train_list[footprints[train1][2]]
                        ctrain2 = train_list[footprints[train2][2]]
                        ctrain1.not_crashed = False
                        ctrain2.not_crashed = False
                        ctrain1.targetspeed(0)
                        ctrain2.targetspeed(0)
                        collision_speed = (ctrain1.mass*ctrain1.velocity + ctrain2.mass*ctrain2.velocity)/(ctrain1.mass + ctrain2.mass)
                        ctrain1.velocity = collision_speed
                        ctrain2.velocity = collision_speed
                        ctrain1.sprite1 = pygame.image.load("images/t0_1c.png")
                        ctrain2.sprite0 = pygame.image.load("images/t0_0c.png")

class Trainmenu:
    def activate():
        train_list.append(Train(basemap,0,2))
        driver_list.append(ATO(train_list[len(train_list)-1], station_list))

class Camcycle:
    count = 0
    def activate():
        Camcycle.count += 1
        if Camcycle.count == len(train_list): Camcycle.count = 0
        basemap.follow = train_list[Camcycle.count]
        if train_list[Camcycle.count]: return "Train " + str(Camcycle.count)
        else: return "Scrolling"

class Skip:
    def activate():
        if Camcycle.count > 0:
            driver_list[Camcycle.count].update(True)           

################

def mainmenu():
    menu_bg = Menu_bg(window1, "images/menu.png")
    mconfirm = Menu_button(window1, "images/confirm.png", (800,146), Mconfirm)
    mchange = Menu_button(window1, "images/confirm.png", (800,346), Mchange)
    txtbx = eztext.Input(x=330, y=146, maxlength=16, color=(255,0,0), prompt='')
    while True:
        events = pygame.event.get()
        for event in events:
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
        mouse.update()
        menu_bg.update()
        txtbx.update(events)
        txtbx.draw(screen)
        mconfirm.update()
        mchange.update()

        if txtbx.value != "":
            railname = txtbx.value + " " + Mchange.railways[Mchange.select]
        else: railname = ""
        label = gamefont.render(railname, 1, (255,0,0))
        screen.blit(label, (100,300))

        msElapsed = clock.tick(100)
        pygame.display.flip()

        if Mconfirm.confirmed: return

def game():
    global basemap, station_list, train_list, driver_list
    basemap = Map(window1, "images/basemap.png", (20, window1.h))
    station_list.append(Station(0, "Central Station", 280))
    station_list.append(Station(1, "City Station", 1035))
    station_list.append(Station(2, "Town Station", 1590))
    train_list.append(Train(basemap,0,2))
    driver_list.append(ATO(train_list[1], station_list))
    trains_button = UI_button(window1, "images/button_trains.png", 0, Trainmenu)
    camera_button = UI_button(window1, "images/button_camera.png", 1, Camcycle, "Scrolling")
    skip_button = UI_button(window1, "images/button_camera.png", 2, Skip)
    panel = Panel(window1, "images/interlocking.png")
    signal_list.append(Signal(basemap, panel, 0, 3))
    signal_list.append(Signal(basemap, panel, 285, 3))
    signal_list.append(Signal(basemap, panel, 1040, 3))
    signal_list.append(Signal(basemap, panel, 1595, 3))
    
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
        mouse.update()
        basemap.update()
        for driver in driver_list:
            if driver:
                driver.update()
        for train in train_list:
            if train:
                train.update()
        panel.update()
        for signal in signal_list:
            if signal:
                signal.update()
        trains_button.update()
        camera_button.update()
        skip_button.update()
        CollisionDetection.update()

        msElapsed = clock.tick(100)
        pygame.display.flip()

################

basemap = False
station_list = []
train_list = [False]
driver_list = [False]
signal_list = [False]
button_list = []

pygame.init()
clock = pygame.time.Clock()
window1 = Window(1000,600)
mouse = Mouse()
gamefont = pygame.font.SysFont("monospace", 15)
#mainmenu()
game()
