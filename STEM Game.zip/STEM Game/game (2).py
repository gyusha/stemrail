import pygame, sys
from pygame.locals import *

###############

class Window:
    def __init__(self, screenWidth, screenHeight):
        global screen
        screen = pygame.display.set_mode((screenWidth,screenHeight),0,32)
        self.w = screenWidth
        self.h = screenHeight

    def resize(self, screenWidth, screenHeight):
        global screen
        screen = pygame.display.set_mode((screenWidth,screenHeight),0,32)
        self.w = screenWidth
        self.h = screenHeight

class Mouse:
    def __init__(self):
        self.pos = (0,0)
        self.click = (0,0)
        self.single = False
        
    def update(self):
        self.pos = pygame.mouse.get_pos()
        new_click = pygame.mouse.get_pressed()
        if self.click[0] - new_click[0] == 1: self.single = True
        else: self.single = False
        self.click = new_click

class Menu_bg:
    def __init__(self, window, image):
        self.back = pygame.image.load(image).convert()
        self.w,self.h = self.back.get_size()
        window.resize(self.w, self.h)
        screen.blit(self.back, (0,0))

class Menu_button:
    pass

class Map:
    def __init__(self, window, image, datum):
        self.back = pygame.image.load(image).convert()
        self.background_size = self.back.get_size()
        self.w,self.h = self.background_size
        self.window = window
        self.x = -self.w + window.w
        self.y = 0 - .5 * window.h
        self.offsetx = 0
        self.offsety = 0
        self.scrollrate = 0
        self.datum = datum

    def update(self, follow = False):
        self.x = self.x + 2 * self.scrollrate
        self.y = self.y - 1 * self.scrollrate
        if follow:
            self.x = -self.w + .5*self.window.w + 2*follow.z
            self.y = 0 - .5 * .5*self.window.h - follow.z
            if self.x < -self.w + self.window.w: self.x = -self.w + self.window.w
            if self.y > 0 - .5 * self.window.h: self.y = 0 - .5 * self.window.h
            if self.x > 0: self.x = 0
            if self.y < -self.h + self.window.h: self.y = -self.h + self.window.h
        self.offsetx = (-self.w + self.window.w) - self.x
        self.offsety = self.y - (0 - .5 * self.window.h)

        screen.blit(self.back, (self.x,self.y))
        
        self.scrollrate = 0
        if mouse.pos[0] >= self.window.w - 100 and mouse.pos[1] <= 100:
            if self.y <= 0 - .5 * self.window.h:
                self.scrollrate = -mouse.pos[1]/10
        elif mouse.pos[0] <= 100 and mouse.pos[1] >= self.window.h - 100:
            if self.x <= 0:
                self.scrollrate = mouse.pos[0]/10

class UI_button:
    def __init__(self):
        pass
    
    def update(self):
        pass
    

class News:
    def __init__(self, tone, headline):
        self.tone = tone
        self.headline = headline

class City:
    def __init__(self, name, player, company):
        self.name = name
        self.player = player
        self.company = company
        self.population = 100000
        self.budget = 1000000
        self.year = 1

    def populate(self, rate):
        self.population += rate

    def revenue(self, amount):
        self.budget += amount

    def spend(self, amount):
        self.budget -= amount

    def newyear(self):
        self.year += 1
        self.budget = 1000000

class Train:
    def __init__(self, localmap, model, length = 2):
        self.localmap = localmap
        self.model = model
        self.length = length
        self.sprite0 = pygame.image.load("images/t0_0.png")
        self.sprite1 = pygame.image.load("images/t0_1.png")
        self.z = 1750
        self.target = 0
        self.velocity = 0
        self.mass = 60000 * length
        self.Crr = .002
        
    def update(self):
        if self.target > self.velocity: force = self.throttle()
        elif self.target < self.velocity: force = self.servicebrake()
        else: force = 0
        self.physics(force)
        self.z = self.z - self.velocity * .1
        if self.z < -50: self.z = 1750
        if mouse.click[1] == 1: print(self.velocity, self.z)
        if mouse.click[2] == 1: print(self.z)
        screen.blit(self.sprite1, (self.localmap.datum[0] - 2*(self.z) - self.localmap.offsetx, self.localmap.datum[1] + (self.z) + self.localmap.offsety))
        screen.blit(self.sprite0, (self.localmap.datum[0] - 2*(self.z + 34) - self.localmap.offsetx, self.localmap.datum[1] + (self.z + 34) + self.localmap.offsety))

    def targetspeed(self, targetkph):
        self.target = targetkph * .2778

    def throttle(self):
        if self.velocity < 10 * .2778: force = 40000
        elif (self.target - self.velocity) < 10 * .2778: force = 40000
        else: force = 70000
        return force

    def servicebrake(self):
        if self.velocity < 10 * .2778: force = -100000
        #elif (self.velocity - self.target) < 10 * .2778: force = -25000
        else: force = -75000
        return force

    def emergencybrake(self):
        pass

    def physics(self, force):
        frictionforce = self.Crr * self.mass * 9.81
        totalforce = force - frictionforce

        acceleration = totalforce / self.mass
        if mouse.click[1] == 1: print(acceleration)

        self.velocity = self.velocity + acceleration * .1
        if self.velocity < 0: self.velocity = 0

class Signal:
    pass

class Station:
    def __init__(self, ID, name, coachstop):
        self.ID = ID
        self.name = name
        self.coachstop = coachstop

class ATO:
    def __init__(self, train, stations_db):
        self.train = train
        self.stations_db = stations_db
        self.next_station = 0

    def update(self):
        if self.train.z < self.stations_db[self.next_station].coachstop or mouse.single:
            self.next_station += 1
        if self.next_station > 2:
            self.next_station = 0
        dtg = self.train.z - self.stations_db[self.next_station].coachstop
        if dtg < 2:
            self.train.targetspeed(0)
        elif dtg < 620:
            self.train.targetspeed(97*(dtg/620)+3)
        else: self.train.targetspeed(100)
        if mouse.click[0] == 1: self.train.targetspeed(0)

################

def mainmenu():
    game()

def game():
    basemap = Map(window1, "images/basemap.png", (1000, 85))
    centralstation = Station(0, "Central Station", 1470)
    citystation = Station(1, "City Station", 715)
    townstation = Station(2, "Town Station", 160)
    SL = [centralstation,citystation,townstation]
    train1 = Train(basemap,0,2)
    tempdriver = ATO(train1, SL)
    controlbutton = UI_button()
    
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
        tempdriver.update()
        mouse.update()
        basemap.update(train1)
        train1.update()
        controlbutton.update()

        msElapsed = clock.tick(100)
        pygame.display.flip()

################

pygame.init()
clock = pygame.time.Clock()
window1 = Window(1000,600)
mouse = Mouse()
mainmenu()
