import pygame, sys
from pygame.locals import *

###############

class Window:
    def __init__(self, screenWidth, screenHeight):
        global screen
        screen = pygame.display.set_mode((screenWidth,screenHeight),0,32)
        self.w = screenWidth
        self.h = screenHeight

    def resize(self, screenWidth, screenHeight):
        global screen
        screen = pygame.display.set_mode((screenWidth,screenHeight),0,32)
        self.w = screenWidth
        self.h = screenHeight

class Menu_bg:
    def __init__(self, window, image):
        self.back = pygame.image.load(image).convert()
        self.w,self.h = self.back.get_size()
        window.resize(self.w, self.h)
        screen.blit(self.back, (0,0))

class Menu_button:
    pass

class Map:
    def __init__(self, window, image, datum = (0,0)):
        self.back = pygame.image.load(image).convert()
        self.background_size = self.back.get_size()
        self.w,self.h = self.background_size
        self.window = window
        self.x = -self.w + window.w
        self.y = 0 - .5 * window.h
        self.scrollrate = 0
        self.datum = datum

    def update(self):
        self.x = self.x + 2 * self.scrollrate
        self.y = self.y - 1 * self.scrollrate

        screen.blit(self.back, (self.x,self.y))

        mousepos = pygame.mouse.get_pos()
        
        self.scrollrate = 0
        if mousepos[0] >= self.window.w - 100 and mousepos[1] <= 100:
            if self.y <= 0 - .5 * self.window.h:
                self.scrollrate = -mousepos[1]/10
        elif mousepos[0] <= 100 and mousepos[1] >= self.window.h - 100:
            if self.x <= 0:
                self.scrollrate = mousepos[0]/10

class UI_button:
    pass

class News:
    def __init__(self, tone, headline):
        self.tone = tone
        self.headline = headline

class City:
    def __init__(self, name, player, company):
        self.name = name
        self.player = player
        self.company = company
        self.population = 100000
        self.budget = 1000000
        self.year = 1

    def populate(self, rate):
        self.population += rate

    def revenue(self, amount):
        self.budget += amount

    def spend(self, amount):
        self.budget -= amount

    def newyear(self):
        self.year += 1
        self.budget = 1000000

class Train:
    def __init__(self, model, length = 2):
        self.model = model
        self.length = length

class Signal:
    pass        

################

pygame.init()
clock = pygame.time.Clock()
window1 = Window(1000,600)

def mainmenu:
    game()

def game:
    basemap = Map(window1, "images/basemap.png")
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()

        basemap.update()

        msElapsed = clock.tick(100)
        pygame.display.flip()
