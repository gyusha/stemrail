#------------ Siemens Model Railway FEP Software Template ------------#
ver = 7
FEP_ID = 'C'
import time
import sys
import telnetlib
import RPi.GPIO as GPIO
#GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD);

HOST = "192.254.34.225" #IP address of the CIP

#Signal/point status list (0=R, 1=Y, 2=G, A=NN, B=NR, C=RN, D=RR, 9=test mode)
SSL = ["9","9","9","9","9","9","9","9","9","9","9","9","9"]
#Track occupation status list (occ, clear, or NA = not handled by this FEP)
TSL = ["NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA"]
PSL = [None,"N","N"]
last_AC = [0] * 55; last_AC[50]=1;last_AC[0]=1;last_AC[4]=1;last_AC[7]=1;last_AC[11]=1;last_AC[14]=1
P1D = "UP" #Current working direction of Chippenham, Platform 1
            #This is detected by the trigger sequence of the sensors at and around the platform

#SigX = [R, Y, G]
Sig1 = [None, None, None]
Sig2 = [None, None, None]
Sig3 = [None, None, None]
Sig4 = [None, None, None]
Sig5 = [None, None, None]
Sig6 = [None, None, None]
Sig7 = [None, None, None]
Sig8 = [None, None, None]
Sig10 = [None, None, None]
Sig12 = [None, None, None]
Sig = [None, Sig1, Sig2, Sig3, Sig4, Sig5, Sig6, Sig7, Sig8, None, Sig10, None, Sig12]
    
y = 0
zL = ["red","yellow","green"]
for n in Sig :
    z = 0
    if n != None:
        for x in n :
            if x != None:
                print("Initialising pin " + str(x) + " for signal " + str(y) + " " + zL[z] + " aspect.")
                GPIO.setup(x, GPIO.OUT)
            z += 1
    y += 1

Axle = [None] * 55
# UP Loop sensors
ATP_0 = 3; Axle[0] = int(ATP_0)
AXC_1 = 5; Axle[1] = int(AXC_1)
AXC_2 = 7; Axle[2] = int(AXC_2)
AXC_3 = 11; Axle[3] = int(AXC_3)
ATP_4 = 13; Axle[4] = int(ATP_4)
AXC_5 = 15; Axle[5] = int(AXC_5)
AXC_6 = 19; Axle[6] = int(AXC_6)
ATP_7 = 21; Axle[7] = int(ATP_7)
AXC_8 = 23; Axle[8] = int(AXC_8)
AXC_9 = 29; Axle[9] = int(AXC_9)
AXC_10 = 31; Axle[10] = int(AXC_10)
ATP_11 = 33; Axle[11] = int(ATP_11)
AXC_12 = 35; Axle[12] = int(AXC_12)
AXC_13 = 37; Axle[13] = int(AXC_13)
ATP_14 = 8; Axle[14] = int(ATP_14)
ATO_50 = 10; Axle[50] = int(ATO_50)
### DOWN Loop sensors
##ATP_20 = None; Axle[20] = int(ATP_20)
##AXC_21 = None; Axle[21] = int(AXC_21)
##AXC_22 = None; Axle[22] = int(AXC_22)
##ATP_23 = None; Axle[23] = int(ATP_23)
##AXC_24 = None; Axle[24] = int(AXC_24)
##ATP_25 = None; Axle[25] = int(ATP_25)
##AXC_26 = None; Axle[26] = int(AXC_26)
##ATP_27 = None; Axle[27] = int(ATP_27)
##AXC_28 = None; Axle[28] = int(AXC_28)
##ATP_29 = None; Axle[29] = int(ATP_29)
##AXC_30 = None; Axle[30] = int(AXC_30)
##ATO_51 = None; Axle[50] = int(ATO_51)
##ATO_52 = None; Axle[50] = int(ATO_52)
### Junction sensors
##AXC_40 = None; Axle[40] = int(AXC_40)
##AXC_41 = None; Axle[41] = int(AXC_41)
   
print("Initialising train detection elements...")
GPIO.setup([x for x in Axle if x is not None], GPIO.IN)


def read_msg(telegr):
    telegr = telegr.split('*')[telegr.split('*').__len__() - 2]
    if telegr.startswith('#'): #This symbol identifies the message as an SSL update.
        global SSL
        SSL = (telegr.strip('#')).split(';')
        control(SSL)
        if len(SSL) == 13: control(SSL)
        else: print('CRITICAL WARNING')
    elif telegr.startswith('$'): #Train entry/exit info
        global TSL
        portal = (telegr.strip('$')).split(';')
        if portal == ['1T']: TSL[2]="occ"
        elif portal == ['2C']: TSL[0]="clear"
        else: return
        send_occupation()
    elif telegr.startswith('Connected to Siemens Model Railway Interlocking'): pass
    else: print('Error: Message corrupt.')

def control(SSL):
    check_points(SSL[0])
    signal = 1
    while signal < 13:
        if SSL[signal] == '2': green(signal)
        elif SSL[signal] == '1': yellow(signal)
        elif SSL[signal] == '9': test(signal)
        else: red(signal)
        signal += 1

def green(signal):
    #Set green LED to high and other two to low
    if Sig[signal] != None and Sig[signal][2] != None:
        GPIO.output(Sig[signal][2], True)
    if Sig[signal] != None and Sig[signal][1] != None:
        GPIO.output(Sig[signal][1], False)
    if Sig[signal] != None and Sig[signal][0] != None:
        GPIO.output(Sig[signal][0], False)

def yellow(signal):
    #Set yellow LED to high and other two to low
    if Sig[signal] != None and Sig[signal][2] != None:
        GPIO.output(Sig[signal][2], False)
    if Sig[signal] != None and Sig[signal][1] != None:
        GPIO.output(Sig[signal][1], True)
    if Sig[signal] != None and Sig[signal][0] != None:
        GPIO.output(Sig[signal][0], False)

def red(signal):
    #Set red LED to high and other two to low
    if Sig[signal] != None and Sig[signal][2] != None:
        GPIO.output(Sig[signal][2], False)
    if Sig[signal] != None and Sig[signal][1] != None:
        GPIO.output(Sig[signal][1], False)
    if Sig[signal] != None and Sig[signal][0] != None:
        GPIO.output(Sig[signal][0], True)

def test(signal):
    #Set all three LEDs to high
    if Sig[signal] != None and Sig[signal][2] != None:
        GPIO.output(Sig[signal][2], True)
    if Sig[signal] != None and Sig[signal][1] != None:
        GPIO.output(Sig[signal][1], True)
    if Sig[signal] != None and Sig[signal][0] != None:
        GPIO.output(Sig[signal][0], True)

def check_points(msg):
    if msg == "A": new_PSL = [None, "N", "N"]
    elif msg == "B": new_PSL = [None, "N", "R"]
    elif msg == "C": new_PSL = [None, "R", "N"]
    elif msg == "D": new_PSL = [None, "R", "R"]
    else: new_PSL = PSL
    if new_PSL == PSL: pass
    else:
        if new_PSL[1] != PSL[1]:
            print("Setting P1 to {}...".format(new_PSL[1]))
            tn.write(('#1;'+new_PSL[1]+'*\n').encode('ascii'))
        if new_PSL[2] != PSL[2]:
            print("Setting P2 to {}...".format(new_PSL[2]))
            tn.write(('#2;'+new_PSL[2]+'*\n').encode('ascii'))
        global PSL
        PSL = new_PSL

def read_axle_counters():
    global last_AC
    new_AC = []
    for n in Axle :
        if n != None:
            reading = GPIO.input(n)
            new_AC.append(reading)
        else:new_AC.append(1)
    if new_AC != last_AC:
        process_axle_counters(new_AC)
        last_AC = []
        for x in new_AC:
            last_AC.append(x)
    else:pass

def process_axle_counters(new_AC):
    global TSL,P1D
    #This logic is specific to FEP C !!! (Disabled until point motors are installed)
##    if last_AC[13] != new_AC[13] and new_AC[13] == 0 and last_AC[14] == 0: P1D = "DOWN"
##    if last_AC[0] != new_AC[0] and new_AC[0] == 0 and last_AC[1] == 0: P1D = "DOWN"
    ## ## Process Clearance
    if last_AC[0] != new_AC[0] and new_AC[0] == 1: pass #Clear ATP
    if last_AC[1] != new_AC[1] and new_AC[1] == 1 and P1D == "UP": TSL[1]="clear";
    if last_AC[1] != new_AC[1] and new_AC[1] == 1 and P1D == "DOWN": TSL[2]="clear";
    if last_AC[2] != new_AC[2] and new_AC[2] == 1: TSL[2]="clear";
    if last_AC[3] != new_AC[3] and new_AC[3] == 1: TSL[3]="clear";
    if last_AC[4] != new_AC[4] and new_AC[4] == 1: pass #Clear ATP
    if last_AC[5] != new_AC[5] and new_AC[5] == 1: TSL[4]="clear";
    if last_AC[6] != new_AC[6] and new_AC[6] == 1: TSL[5]="clear";
    if last_AC[7] != new_AC[7] and new_AC[7] == 1: pass #Clear ATP
    if last_AC[8] != new_AC[8] and new_AC[8] == 1: TSL[6]="clear";
    if last_AC[9] != new_AC[9] and new_AC[9] == 1: TSL[7]="clear";
    if last_AC[10] != new_AC[10] and new_AC[10] == 1: TSL[8]="clear";
    if last_AC[11] != new_AC[11] and new_AC[11] == 1: pass #Clear ATP
    if last_AC[12] != new_AC[12] and new_AC[12] == 1: TSL[9]="clear";
    if last_AC[13] != new_AC[13] and new_AC[13] == 1 and P1D == "UP": TSL[0]="clear";
    if last_AC[13] != new_AC[13] and new_AC[13] == 1 and P1D == "DOWN": TSL[1]="clear";
    if last_AC[14] != new_AC[14] and new_AC[14] == 1: pass #Clear ATP
    if last_AC[50] != new_AC[50] and new_AC[50] == 1: pass #Clear ATO
    ## ## Process Trigger
    if last_AC[0] != new_AC[0] and new_AC[0] == 0 and new_AC[1] == 1: send_ATP(0) #Trigger ATP
    if last_AC[1] != new_AC[1] and new_AC[1] == 0: TSL[1]="occ";TSL[2]="occ"
    if last_AC[2] != new_AC[2] and new_AC[2] == 0: TSL[2]="occ";TSL[3]="occ"
    if last_AC[3] != new_AC[3] and new_AC[3] == 0: TSL[3]="occ";TSL[4]="occ"
    if last_AC[4] != new_AC[4] and new_AC[4] == 0: send_ATP(4) #Trigger ATP
    if last_AC[5] != new_AC[5] and new_AC[5] == 0: TSL[4]="occ";TSL[5]="occ"
    if last_AC[6] != new_AC[6] and new_AC[6] == 0: TSL[5]="occ";TSL[6]="occ"
    if last_AC[7] != new_AC[7] and new_AC[7] == 0: send_ATP(7) #Trigger ATP
    if last_AC[8] != new_AC[8] and new_AC[8] == 0: TSL[6]="occ";TSL[7]="occ"
    if last_AC[9] != new_AC[9] and new_AC[9] == 0: TSL[7]="occ";TSL[8]="occ"
    if last_AC[10] != new_AC[10] and new_AC[10] == 0: TSL[8]="occ";TSL[9]="occ"
    if last_AC[11] != new_AC[11] and new_AC[11] == 0: send_ATP(11) #Trigger ATP
    if last_AC[12] != new_AC[12] and new_AC[12] == 0: TSL[9]="occ";TSL[0]="occ"
    if last_AC[13] != new_AC[13] and new_AC[13] == 0: TSL[0]="occ";TSL[1]="occ"
    if last_AC[14] != new_AC[14] and new_AC[14] == 0 and new_AC[13] == 1: send_ATP(13) #Trigger ATP
    if last_AC[50] != new_AC[50] and new_AC[50] == 0: TSL[1]="occ"; send_ATP(50) #Trigger ATO
    # # Cleanup
    if last_AC[13] != new_AC[13] and new_AC[13] == 1: P1D = "UP"
    if last_AC[1] != new_AC[1] and new_AC[1] == 1: P1D = "UP"
    send_occupation()
    
def send_occupation():
    #Send track occupation update to CIP
    msg = "$"
    track = 0
    while track < 16:
        if track != 0: msg = msg + ';'
        msg = msg + str(TSL[track])
        track += 1
    msg = msg + '*\n'
    tn.write((msg).encode('ascii'))
    print(msg)
    
def send_ATP(location):
    #Send ATP notice to CIP
    msg = "@"
    msg = msg + str(location)
    msg = msg + '*\n'
    tn.write((msg).encode('ascii'))
    print(msg)

try:
    control(SSL)
    print("Initialising Telnet...")
    print()
    tn = telnetlib.Telnet(HOST, 7777)
    time.sleep(1)
    msg_in = tn.read_very_eager().decode('ascii')
    print(msg_in)
    tn.write(("FEP "+ FEP_ID +"\n").encode('ascii'))
    read_msg(msg_in)

    ####  MAIN LOOP  ####
    while True:
        time.sleep(.1)
        msg_in = tn.read_very_eager().decode('ascii')
        if msg_in != "":
            print(msg_in)
            read_msg(msg_in)
        read_axle_counters() #To be enabled once axle counters are installed.

    tn.close

##except KeyboardInterrupt:
##    print()
##    print ("Shutting down TFM...")
##
##except:
##    print()
##    print ("Failing safe...")

finally:
    #When the TFM shuts down for any reason, put all signals to red. (Fail safe)
    x = 1
    while x < 13:
        red(x)
        x += 1
    #GPIO.cleanup()
