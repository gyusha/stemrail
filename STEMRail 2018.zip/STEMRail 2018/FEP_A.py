#------------ Siemens Model Railway FEP Software Template ------------#
ver = 7
FEP_ID = 'A'
import time
import sys
import telnetlib
import RPi.GPIO as GPIO
#GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD);

HOST = "localhost" #IP address of the CIP

#Signal/point status list (0=R, 1=Y, 2=G, A=NN, B=NR, C=RN, D=RR, 9=test mode)
SSL = ["9","9","9","9","9","9","9","9","9","9","9","9","9"]
#Track occupation status list (occ, clear, or NA = not handled by this FEP)
TSL = ["NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA","NA"]
last_AC = [0] * 55; last_AC[20]=1;last_AC[23]=1;last_AC[25]=1;last_AC[27]=1;last_AC[29]=1;last_AC[51]=1;last_AC[52]=1

#SigX = [R, Y, G]
Sig1 = [3, 5, 7]
Sig2 = [None, None, None]
Sig3 = [11, 13, 15]
Sig4 = [None, None, None]
Sig5 = [19, 21, 23]
Sig6 = [None, None, None]
Sig7 = [29, 31, 33]
Sig8 = [None, None, None]
Sig10 = [None, None, None]
Sig12 = [None, None, None]
Sig = [None, Sig1, Sig2, Sig3, Sig4, Sig5, Sig6, Sig7, Sig8, None, Sig10, None, Sig12]
    
y = 0
zL = ["red","yellow","green"]
for n in Sig :
    z = 0
    if n != None:
        for x in n :
            if x != None:
                print("Initialising pin " + str(x) + " for signal " + str(y) + " " + zL[z] + " aspect.")
                GPIO.setup(x, GPIO.OUT)
            z += 1
    y += 1

Axle = [None] * 55
# UP Loop sensors
##ATP_0 = 3; Axle[0] = int(ATP_0)
##AXC_1 = 5; Axle[1] = int(AXC_1)
##AXC_2 = 7; Axle[2] = int(AXC_2)
##AXC_3 = 11; Axle[3] = int(AXC_3)
##ATP_4 = 13; Axle[4] = int(ATP_4)
##AXC_5 = 15; Axle[5] = int(AXC_5)
##AXC_6 = 19; Axle[6] = int(AXC_6)
##ATP_7 = 21; Axle[7] = int(ATP_7)
##AXC_8 = 23; Axle[8] = int(AXC_8)
##AXC_9 = 29; Axle[9] = int(AXC_9)
##AXC_10 = 31; Axle[10] = int(AXC_10)
##ATP_11 = 33; Axle[11] = int(ATP_11)
##AXC_12 = 35; Axle[12] = int(AXC_12)
##AXC_13 = 37; Axle[13] = int(AXC_13)
##ATP_14 = 8; Axle[14] = int(ATP_14)
##ATO_50 = 10; Axle[50] = int(ATO_50)
### DOWN Loop sensors
ATP_20 = 35; Axle[20] = int(ATP_20)
AXC_21 = 37; Axle[21] = int(AXC_21)
AXC_22 = 8; Axle[22] = int(AXC_22)
ATP_23 = 10; Axle[23] = int(ATP_23)
AXC_24 = 12; Axle[24] = int(AXC_24)
ATP_25 = 16; Axle[25] = int(ATP_25)
AXC_26 = 18; Axle[26] = int(AXC_26)
ATP_27 = 22; Axle[27] = int(ATP_27)
AXC_28 = 24; Axle[28] = int(AXC_28)
ATP_29 = 26; Axle[29] = int(ATP_29)
AXC_30 = 32; Axle[30] = int(AXC_30)
ATO_51 = 36; Axle[50] = int(ATO_51)
ATO_52 = 38; Axle[50] = int(ATO_52)
### Junction sensors
##AXC_40 = None; Axle[40] = int(AXC_40)
##AXC_41 = None; Axle[41] = int(AXC_41)
   
print("Initialising train detection elements...")
GPIO.setup([x for x in Axle if x is not None], GPIO.IN)


def read_msg(telegr):
    telegr = telegr.split('*')[telegr.split('*').__len__() - 2]
    if telegr.startswith('#'): #This symbol identifies the message as an SSL update.
        global SSL
        SSL = (telegr.strip('#')).split(';')
        control(SSL)
        if len(SSL) == 13: control(SSL)
        else: print('CRITICAL WARNING')
    elif telegr.startswith('$'): #Train entry/exit info
        global TSL
        portal = (telegr.strip('$')).split(';')
        if portal == ['1C']: TSL[11]="clear"
        elif portal == ['2T']: TSL[15]="occ"
        else: return
        send_occupation()
    elif telegr.startswith('Connected to Siemens Model Railway Interlocking'): pass
    else: print('Error: Message corrupt.')

def control(SSL):
    signal = 1
    while signal < 13:
        if SSL[signal] == '2': green(signal)
        elif SSL[signal] == '1': yellow(signal)
        elif SSL[signal] == '9': test(signal)
        else: red(signal)
        signal += 1

def green(signal):
    #Set green LED to high and other two to low
    if Sig[signal] != None and Sig[signal][2] != None:
        GPIO.output(Sig[signal][2], True)
    if Sig[signal] != None and Sig[signal][1] != None:
        GPIO.output(Sig[signal][1], False)
    if Sig[signal] != None and Sig[signal][0] != None:
        GPIO.output(Sig[signal][0], False)

def yellow(signal):
    #Set yellow LED to high and other two to low
    if Sig[signal] != None and Sig[signal][2] != None:
        GPIO.output(Sig[signal][2], False)
    if Sig[signal] != None and Sig[signal][1] != None:
        GPIO.output(Sig[signal][1], True)
    if Sig[signal] != None and Sig[signal][0] != None:
        GPIO.output(Sig[signal][0], False)

def red(signal):
    #Set red LED to high and other two to low
    if Sig[signal] != None and Sig[signal][2] != None:
        GPIO.output(Sig[signal][2], False)
    if Sig[signal] != None and Sig[signal][1] != None:
        GPIO.output(Sig[signal][1], False)
    if Sig[signal] != None and Sig[signal][0] != None:
        GPIO.output(Sig[signal][0], True)

def test(signal):
    #Set all three LEDs to high
    if Sig[signal] != None and Sig[signal][2] != None:
        GPIO.output(Sig[signal][2], True)
    if Sig[signal] != None and Sig[signal][1] != None:
        GPIO.output(Sig[signal][1], True)
    if Sig[signal] != None and Sig[signal][0] != None:
        GPIO.output(Sig[signal][0], True)



def read_axle_counters():
    global last_AC
    new_AC = []
    for n in Axle :
        if n != None:
            reading = GPIO.input(n)
            new_AC.append(reading)
        else:new_AC.append(1)
    if new_AC != last_AC:
        process_axle_counters(new_AC)
        last_AC = []
        for x in new_AC:
            last_AC.append(x)
    else:pass

def process_axle_counters(new_AC):
    global TSL
    #This logic is specific to FEP A !!!
    ## ## Process Clearance
    if last_AC[20] != new_AC[20] and new_AC[20] == 1: pass #Clear ATP
    if last_AC[21] != new_AC[21] and new_AC[21] == 1: TSL[10]="clear"
    if last_AC[22] != new_AC[22] and new_AC[22] == 1: TSL[15]="clear"
    if last_AC[23] != new_AC[23] and new_AC[23] == 1: pass #Clear ATP
    if last_AC[24] != new_AC[24] and new_AC[24] == 1: TSL[14]="clear"
    if last_AC[25] != new_AC[25] and new_AC[25] == 1: pass #Clear ATP
    if last_AC[26] != new_AC[26] and new_AC[26] == 1: TSL[13]="clear"
    if last_AC[27] != new_AC[27] and new_AC[27] == 1: pass #Clear ATP
    if last_AC[28] != new_AC[28] and new_AC[28] == 1: TSL[12]="clear"
    if last_AC[29] != new_AC[29] and new_AC[29] == 1: pass #Clear ATP
    if last_AC[30] != new_AC[30] and new_AC[30] == 1: TSL[11]="clear"
    if last_AC[51] != new_AC[51] and new_AC[51] == 1: pass #Clear ATO
    if last_AC[52] != new_AC[52] and new_AC[52] == 1: pass #Clear ATO
    ## ## Process Trigger
    if last_AC[20] != new_AC[20] and new_AC[20] == 0: send_ATP(20) #Trigger ATP
    if last_AC[21] != new_AC[21] and new_AC[21] == 0: TSL[10]="occ";TSL[15]="occ"
    if last_AC[22] != new_AC[22] and new_AC[22] == 0: TSL[15]="occ";TSL[14]="occ"
    if last_AC[23] != new_AC[23] and new_AC[23] == 0: send_ATP(23) #Trigger ATP
    if last_AC[24] != new_AC[24] and new_AC[24] == 0: TSL[14]="occ";TSL[13]="occ"
    if last_AC[25] != new_AC[25] and new_AC[25] == 0: send_ATP(25) #Trigger ATP
    if last_AC[26] != new_AC[26] and new_AC[26] == 0: TSL[13]="occ";TSL[12]="occ"
    if last_AC[27] != new_AC[27] and new_AC[27] == 0: send_ATP(27) #Trigger ATP
    if last_AC[28] != new_AC[28] and new_AC[28] == 0: TSL[12]="occ";TSL[11]="occ"
    if last_AC[29] != new_AC[29] and new_AC[29] == 0: send_ATP(29) #Trigger ATP
    if last_AC[30] != new_AC[30] and new_AC[30] == 0: TSL[11]="occ";TSL[10]="occ"
    if last_AC[51] != new_AC[51] and new_AC[51] == 0: TSL[10]="occ"; send_ATP(51) #Trigger ATO
    if last_AC[52] != new_AC[52] and new_AC[52] == 0: TSL[13]="occ"; send_ATP(52) #Trigger ATO
    # # Cleanup
    #send_occupation()
    
def send_occupation():
    #Send track occupation update to CIP
    msg = "$"
    track = 0
    while track < 16:
        if track != 0: msg = msg + ';'
        msg = msg + str(TSL[track])
        track += 1
    msg = msg + '*\n'
    tn.write((msg).encode('ascii'))
    print(msg)
    
def send_ATP(location):
    #Send ATP notice to CIP
##    msg = "@"
##    msg = msg + str(location)
##    msg = msg + '*\n'
##    tn.write((msg).encode('ascii'))
##    print(msg)
    pass #(disabled until down loop p-way work completed)

try:
    control(SSL)
    print("Initialising Telnet...")
    print()
    tn = telnetlib.Telnet(HOST, 7777)
    time.sleep(1)
    msg_in = tn.read_very_eager().decode('ascii')
    print(msg_in)
    tn.write(("FEP "+ FEP_ID +"\n").encode('ascii'))
    read_msg(msg_in)

    ####  MAIN LOOP  ####
    while True:
        time.sleep(.1)
        msg_in = tn.read_very_eager().decode('ascii')
        if msg_in != "":
            print(msg_in)
            read_msg(msg_in)
        read_axle_counters() #To be enabled once axle counters are installed.

    tn.close

##except KeyboardInterrupt:
##    print()
##    print ("Shutting down TFM...")
##
##except:
##    print()
##    print ("Failing safe...")

finally:
    #When the TFM shuts down for any reason, put all signals to red. (Fail safe)
    x = 1
    while x < 13:
        red(x)
        x += 1
    #GPIO.cleanup()
