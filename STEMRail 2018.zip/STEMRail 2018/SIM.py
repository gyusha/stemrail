#------------ Siemens Model Railway Simulation System ------------#

    #Import GUI and network protocol libraries
import tkinter
from tkinter import *
import tkinter.messagebox as messagebox
import itertools
from itertools import *
import time
import sys
import telnetlib

    #Define key global variables
#TSL = Track Status List
#      [A1A, A2A, A1B, A2B, A3B, AC, AD, A1E, A2E, A3E, BA, BB, BC, BD, B1E, B2E]
TSL = ["clear","clear","clear","clear","clear","clear","clear","clear","clear","clear","clear","clear","clear","clear","clear","clear"]
test_occupy = [False]*55
last_AC = [1]*55
#SSL = Signal Status List
SSL = ["reserved","red","red","red","red","red","red","red","red","red","red","red","red"]
SSLtn = ['A','0','0','0','0','0','0','0','0','0','0','0','0']
#PSL = Point Status List
PSL = ["reserved","N","N"]
P1D = "UP"


########### Define TELNET CLIENT Functions ###########

def read_msg(telegr):
    telegr = telegr.split('*')[telegr.split('*').__len__() - 2]
    if telegr.startswith('#'): #This symbol identifies the message as an SSL update.
        global SSLtn
        SSLtn = (telegr.strip('#')).split(';')
        control(SSLtn)
        if len(SSLtn) == 13: control(SSLtn)
        else: print('CRITICAL WARNING')
    elif telegr.startswith('$'): #Train entry/exit info
        global TSL
        portal = (telegr.strip('$')).split(';')
        if portal == ['1T']: TSL[2]="occ"
        elif portal == ['2C']: TSL[0]="clear"
        elif portal == ['1C']: TSL[11]="clear"
        elif portal == ['2T']: TSL[15]="occ"
        else: return
        send_occupation()
    elif telegr.startswith('Connected to Siemens Model Railway Interlocking'): pass
    else: print('Error: Message corrupt.')
    reset("signals")

def control(SSLtn):
    check_points(SSLtn[0])
    signal = 1
    while signal < 13:
        if SSLtn[signal] == '2': green(signal)
        elif SSLtn[signal] == '1': yellow(signal)
        elif SSLtn[signal] == '9': test(signal)
        else: red(signal)
        signal += 1

def green(signal):
    global SSL
    SSL[signal] = "green"

def yellow(signal):
    global SSL
    SSL[signal] = "yellow"

def red(signal):
    global SSL
    SSL[signal] = "red"

def test(signal):
    pass

def check_points(msg):
    global PSL
    if msg == "A": new_PSL = [None, "N", "N"]
    elif msg == "B": new_PSL = [None, "N", "R"]
    elif msg == "C": new_PSL = [None, "R", "N"]
    elif msg == "D": new_PSL = [None, "R", "R"]
    else: new_PSL = PSL
    if new_PSL == PSL: pass
    else:
        if new_PSL[1] != PSL[1]:
            call_point(1, new_PSL[1], 0)
            print("Setting P1 to {}...".format(new_PSL[1]))
            tn.write(('#1;'+new_PSL[1]+'*\n').encode('ascii'))
        if new_PSL[2] != PSL[2]:
            call_point(2, new_PSL[2], 0)
            print("Setting P2 to {}...".format(new_PSL[2]))
            tn.write(('#2;'+new_PSL[2]+'*\n').encode('ascii'))
        PSL = new_PSL

def read_axle_counters(axc):
    print('read '+str(axc))
    global last_AC
    new_AC = []
    a=0
    for n in last_AC:
        if a == axc: new_AC.append(abs(n-1))
        else: new_AC.append(n)
        a+=1
    print(last_AC)
    print(new_AC)
    if new_AC != last_AC:
        print('different')
        process_axle_counters(new_AC)
        last_AC = []
        for x in new_AC:
            last_AC.append(x)
    else:pass

def process_axle_counters(new_AC):
    print('process')
    global TSL,P1D
    #This logic is specific to FEP C !!!
    if last_AC[13] != new_AC[13] and new_AC[13] == 0 and last_AC[14] == 0: P1D = "DOWN"
    if last_AC[0] != new_AC[0] and new_AC[0] == 0 and last_AC[1] == 0: P1D = "DOWN"
    ## ## Process Clearance
    if last_AC[0] != new_AC[0] and new_AC[0] == 1: pass #Clear ATP
    if last_AC[1] != new_AC[1] and new_AC[1] == 1 and P1D == "UP": TSL[1]="clear";
    if last_AC[1] != new_AC[1] and new_AC[1] == 1 and P1D == "DOWN": TSL[2]="clear";
    if last_AC[2] != new_AC[2] and new_AC[2] == 1: TSL[2]="clear";
    if last_AC[3] != new_AC[3] and new_AC[3] == 1: TSL[3]="clear";
    if last_AC[4] != new_AC[4] and new_AC[4] == 1: pass #Clear ATP
    if last_AC[5] != new_AC[5] and new_AC[5] == 1: TSL[4]="clear";
    if last_AC[6] != new_AC[6] and new_AC[6] == 1: TSL[5]="clear";
    if last_AC[7] != new_AC[7] and new_AC[7] == 1: pass #Clear ATP
    if last_AC[8] != new_AC[8] and new_AC[8] == 1: TSL[6]="clear";
    if last_AC[9] != new_AC[9] and new_AC[9] == 1: TSL[7]="clear";
    if last_AC[10] != new_AC[10] and new_AC[10] == 1: TSL[8]="clear";
    if last_AC[11] != new_AC[11] and new_AC[11] == 1: pass #Clear ATP
    if last_AC[12] != new_AC[12] and new_AC[12] == 1: TSL[9]="clear";
    if last_AC[13] != new_AC[13] and new_AC[13] == 1 and P1D == "UP": TSL[0]="clear";
    if last_AC[13] != new_AC[13] and new_AC[13] == 1 and P1D == "DOWN": TSL[1]="clear";
    if last_AC[14] != new_AC[14] and new_AC[14] == 1: pass #Clear ATP
    if last_AC[50] != new_AC[50] and new_AC[50] == 1: pass #Clear ATO
    if last_AC[20] != new_AC[20] and new_AC[20] == 1: pass #Clear ATP
    if last_AC[21] != new_AC[21] and new_AC[21] == 1: TSL[10]="clear"
    if last_AC[22] != new_AC[22] and new_AC[22] == 1: TSL[15]="clear"
    if last_AC[23] != new_AC[23] and new_AC[23] == 1: pass #Clear ATP
    if last_AC[24] != new_AC[24] and new_AC[24] == 1: TSL[14]="clear"
    if last_AC[25] != new_AC[25] and new_AC[25] == 1: pass #Clear ATP
    if last_AC[26] != new_AC[26] and new_AC[26] == 1: TSL[13]="clear"
    if last_AC[27] != new_AC[27] and new_AC[27] == 1: pass #Clear ATP
    if last_AC[28] != new_AC[28] and new_AC[28] == 1: TSL[12]="clear"
    if last_AC[29] != new_AC[29] and new_AC[29] == 1: pass #Clear ATP
    if last_AC[30] != new_AC[30] and new_AC[30] == 1: TSL[11]="clear"
    if last_AC[51] != new_AC[51] and new_AC[51] == 1: pass #Clear ATO
    if last_AC[52] != new_AC[52] and new_AC[52] == 1: pass #Clear ATO
    if last_AC[40] != new_AC[40] and new_AC[40] == 1: interzonal("1C")
    if last_AC[41] != new_AC[41] and new_AC[41] == 1: interzonal("2C")
    ## ## Process Trigger
    if last_AC[0] != new_AC[0] and new_AC[0] == 0 and new_AC[1] == 1: send_ATP(0) #Trigger ATP
    if last_AC[1] != new_AC[1] and new_AC[1] == 0: TSL[1]="occ";TSL[2]="occ"
    if last_AC[2] != new_AC[2] and new_AC[2] == 0: TSL[2]="occ";TSL[3]="occ"
    if last_AC[3] != new_AC[3] and new_AC[3] == 0: TSL[3]="occ";TSL[4]="occ"
    if last_AC[4] != new_AC[4] and new_AC[4] == 0: send_ATP(4) #Trigger ATP
    if last_AC[5] != new_AC[5] and new_AC[5] == 0: TSL[4]="occ";TSL[5]="occ"
    if last_AC[6] != new_AC[6] and new_AC[6] == 0: TSL[5]="occ";TSL[6]="occ"
    if last_AC[7] != new_AC[7] and new_AC[7] == 0: send_ATP(7) #Trigger ATP
    if last_AC[8] != new_AC[8] and new_AC[8] == 0: TSL[6]="occ";TSL[7]="occ"
    if last_AC[9] != new_AC[9] and new_AC[9] == 0: TSL[7]="occ";TSL[8]="occ"
    if last_AC[10] != new_AC[10] and new_AC[10] == 0: TSL[8]="occ";TSL[9]="occ"
    if last_AC[11] != new_AC[11] and new_AC[11] == 0: send_ATP(11) #Trigger ATP
    if last_AC[12] != new_AC[12] and new_AC[12] == 0: TSL[9]="occ";TSL[0]="occ"
    if last_AC[13] != new_AC[13] and new_AC[13] == 0: TSL[0]="occ";TSL[1]="occ"
    if last_AC[14] != new_AC[14] and new_AC[14] == 0 and new_AC[13] == 1: send_ATP(13) #Trigger ATP
    if last_AC[50] != new_AC[50] and new_AC[50] == 0: TSL[1]="occ"; send_ATP(50) #Trigger ATO
    if last_AC[20] != new_AC[20] and new_AC[20] == 0: send_ATP(20) #Trigger ATP
    if last_AC[21] != new_AC[21] and new_AC[21] == 0: TSL[10]="occ";TSL[15]="occ"
    if last_AC[22] != new_AC[22] and new_AC[22] == 0: TSL[15]="occ";TSL[14]="occ"
    if last_AC[23] != new_AC[23] and new_AC[23] == 0: send_ATP(23) #Trigger ATP
    if last_AC[24] != new_AC[24] and new_AC[24] == 0: TSL[14]="occ";TSL[13]="occ"
    if last_AC[25] != new_AC[25] and new_AC[25] == 0: send_ATP(25) #Trigger ATP
    if last_AC[26] != new_AC[26] and new_AC[26] == 0: TSL[13]="occ";TSL[12]="occ"
    if last_AC[27] != new_AC[27] and new_AC[27] == 0: send_ATP(27) #Trigger ATP
    if last_AC[28] != new_AC[28] and new_AC[28] == 0: TSL[12]="occ";TSL[11]="occ"
    if last_AC[29] != new_AC[29] and new_AC[29] == 0: send_ATP(29) #Trigger ATP
    if last_AC[30] != new_AC[30] and new_AC[30] == 0: TSL[11]="occ";TSL[10]="occ"
    if last_AC[51] != new_AC[51] and new_AC[51] == 0: TSL[10]="occ"; send_ATP(51) #Trigger ATO
    if last_AC[52] != new_AC[52] and new_AC[52] == 0: TSL[13]="occ"; send_ATP(52) #Trigger ATO
    if last_AC[40] != new_AC[40] and new_AC[40] == 0: interzonal("1T")
    if last_AC[41] != new_AC[41] and new_AC[41] == 0: interzonal("2T")
    # # Cleanup
    if last_AC[13] != new_AC[13] and new_AC[13] == 1: P1D = "UP"
    if last_AC[1] != new_AC[1] and new_AC[1] == 1: P1D = "UP"
    print(TSL)
    send_occupation()

def send_occupation():
    #Send track occupation update to CIP
    msg = "$"
    track = 0
    while track < 16:
        if track != 0: msg = msg + ';'
        msg = msg + str(TSL[track])
        trackFX[track](TSL[track])
        track += 1
    msg = msg + '*\n'
    tn.write((msg).encode('ascii'))
    print(msg)

def send_ATP(location):
    #Send ATP notice to CIP
    msg = "@"
    msg = msg + str(location)
    msg = msg + '*\n'
    tn.write((msg).encode('ascii'))
    print(msg)

def interzonal(location):
    #Send zone transition notice to CIP
    msg = "@"
    msg = msg + location + '*\n'
    tn.write((msg).encode('ascii'))
    print(msg)

########### /TELNET CLIENT Funtions ###########


########### Create GUI Window ###########
print("Initialising simulation...",end=" ")
GUI = tkinter.Tk()
GUI.title("Siemens Model Railway Simulator") # Window Title
GUI.geometry("1000x600") # Window Size
background = tkinter.PhotoImage(file= r"images/SIM_MAIN.gif")
cv = tkinter.Canvas()
cv.pack(side='top', fill='both', expand='yes')
cv.create_image(0, 0, image=background, anchor='nw')
w1 = IntVar()
w2 = IntVar()
    ###### Load images #####
def load_track_images():
    A1A_img = [tkinter.PhotoImage(file= r"images/A1A_red.gif"), tkinter.PhotoImage(file= r"images/A1A_blue.gif")]
    A2A_img = [tkinter.PhotoImage(file= r"images/A2A_red.gif"), tkinter.PhotoImage(file= r"images/A2A_blue.gif")]
    A1B_img = [tkinter.PhotoImage(file= r"images/A1B_red.gif"), tkinter.PhotoImage(file= r"images/A1B_blue.gif")]
    A2B_img = [tkinter.PhotoImage(file= r"images/A2B_red.gif"), tkinter.PhotoImage(file= r"images/A2B_blue.gif")]
    A3B_img = [tkinter.PhotoImage(file= r"images/A3B_red.gif"), tkinter.PhotoImage(file= r"images/A3B_blue.gif")]
    AC_img = [tkinter.PhotoImage(file= r"images/AC_red.gif"), tkinter.PhotoImage(file= r"images/AC_blue.gif")]
    AD_img = [tkinter.PhotoImage(file= r"images/AD_red.gif"), tkinter.PhotoImage(file= r"images/AD_blue.gif")]
    A1E_img = [tkinter.PhotoImage(file= r"images/A1E_red.gif"), tkinter.PhotoImage(file= r"images/A1E_blue.gif")]
    A2E_img = [tkinter.PhotoImage(file= r"images/A2E_red.gif"), tkinter.PhotoImage(file= r"images/A2E_blue.gif")]
    A3E_img = [tkinter.PhotoImage(file= r"images/A3E_red.gif"), tkinter.PhotoImage(file= r"images/A3E_blue.gif")]
    BA_img = [tkinter.PhotoImage(file= r"images/BA_red.gif"), tkinter.PhotoImage(file= r"images/BA_blue.gif")]
    BB_img = [tkinter.PhotoImage(file= r"images/BB_red.gif"), tkinter.PhotoImage(file= r"images/BB_blue.gif")]
    BC_img = [tkinter.PhotoImage(file= r"images/BC_red.gif"), tkinter.PhotoImage(file= r"images/BC_blue.gif")]
    BD_img = [tkinter.PhotoImage(file= r"images/BD_red.gif"), tkinter.PhotoImage(file= r"images/BD_blue.gif")]
    B1E_img = [tkinter.PhotoImage(file= r"images/B1E_red.gif"), tkinter.PhotoImage(file= r"images/B1E_blue.gif")]
    B2E_img = [tkinter.PhotoImage(file= r"images/B2E_red.gif"), tkinter.PhotoImage(file= r"images/B2E_blue.gif")]
    return [A1A_img,A2A_img,A1B_img,A2B_img,A3B_img,AC_img,AD_img,A1E_img,A2E_img,A3E_img,BA_img,BB_img,BC_img,BD_img,B1E_img,B2E_img]
def load_signal_images():
    sig_img = [None]
    x = 1
    while x < 13:
        if (x == 9 or x == 11) == False:
            sig_img.append([tkinter.PhotoImage(file= r"images/S" + str(x) + "_red.gif"), tkinter.PhotoImage(file= r"images/S" + str(x) + "_yellow.gif"), tkinter.PhotoImage(file= r"images/S" + str(x) + "_green.gif")])
        else:
            sig_img.append(None)
        x += 1
    return sig_img
def load_point_images():
    point_img = [None]
    x = 1
    while x < 3:
        point_img.append([tkinter.PhotoImage(file= r"images/P" + str(x) + "_N.gif"), tkinter.PhotoImage(file= r"images/P" + str(x) + "_R.gif")])
        x += 1
    return point_img
track_img = load_track_images()
sig_img = load_signal_images()
point_img = load_point_images()
ti_loaded = [None]*16
si_loaded = [None]*13
pi_loaded = [None]*3

    ###### Create UI buttons #####

  # Points P1A & P1B
W1_lab = Label(GUI, text = "P1", bg = "#AD1414", anchor='nw')
W1_lab.place(x=62, y=150)
W1N_lab = Label(GUI, text = "N", bg = "#AD1414", anchor='nw')
W1N_lab.place(x=50, y=170)
W1N_btn = Radiobutton(GUI, variable=w1, value=0, bg = "#AD1414", state="disabled", command = lambda:call_point(1,"N",1))
W1N_btn.place(x=45, y=190, anchor='nw')
W1R_lab = Label(GUI, text = "R", bg = "#AD1414", anchor='nw')
W1R_lab.place(x=80, y=170)
W1R_btn = Radiobutton(GUI, variable=w1, value=1, bg = "#AD1414", state="disabled", command = lambda:call_point(1,"R",1))
W1R_btn.place(x=75, y=190, anchor='nw')
W1N_btn.select()

  # Point P2A & P2B
W2_lab = Label(GUI, text = "P2", bg = "#AD1414", anchor='nw')
W2_lab.place(x=162, y=150)
W2N_lab = Label(GUI, text = "N", bg = "#AD1414", anchor='nw')
W2N_lab.place(x=150, y=170)
W2N_btn = Radiobutton(GUI, variable=w2, value=0, bg = "#AD1414", state="disabled", command = lambda:call_point(2,"N",1))
W2N_btn.place(x=145, y=190, anchor='nw')
W2R_lab = Label(GUI, text = "R", bg = "#AD1414", anchor='nw')
W2R_lab.place(x=180, y=170)
W2R_btn = Radiobutton(GUI, variable=w2, value=1, bg = "#AD1414", state="disabled", command = lambda:call_point(2,"R",1))
W2R_btn.place(x=175, y=190, anchor='nw')
W2N_btn.select()

  # Reset buttons
reset_btn = Button(GUI, text = "RESET", command = lambda:reset("all"))
reset_btn.place(x=155, y=485)

  # Train detection buttons
n=0
for x in test_occupy:
    test_occupy[n] = Variable()
    n+=1
A0_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(0)], bg = "light grey", variable = test_occupy[0])
A0_btn.place(x=552, y=528, anchor='center')
A1_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(1)], bg = "light grey", variable = test_occupy[1])
A1_btn.place(x=508, y=528, anchor='center')
A2_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(2)], bg = "light grey", variable = test_occupy[2])
A2_btn.place(x=325, y=481, anchor='center')
A3_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(3)], bg = "light grey", variable = test_occupy[3])
A3_btn.place(x=325, y=223, anchor='center')
A4_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(4)], bg = "light grey", variable = test_occupy[4])
A4_btn.place(x=412, y=106, anchor='center')
A5_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(5)], bg = "light grey", variable = test_occupy[5])
A5_btn.place(x=472, y=106, anchor='center')
A6_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(6)], bg = "light grey", variable = test_occupy[6])
A6_btn.place(x=635, y=106, anchor='center')
A7_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(7)], bg = "light grey", variable = test_occupy[7])
A7_btn.place(x=769, y=106, anchor='center')
A8_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(8)], bg = "light grey", variable = test_occupy[8])
A8_btn.place(x=820, y=106, anchor='center')
A9_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(9)], bg = "light grey", variable = test_occupy[9])
A9_btn.place(x=966, y=222, anchor='center')
A10_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(10)], bg = "light grey", variable = test_occupy[10])
A10_btn.place(x=966, y=362, anchor='center')
A11_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(11)], bg = "light grey", variable = test_occupy[11])
A11_btn.place(x=962, y=483, anchor='center')
A12_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(12)], bg = "light grey", variable = test_occupy[12])
A12_btn.place(x=931, y=513, anchor='center')
A13_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(13)], bg = "light grey", variable = test_occupy[13])
A13_btn.place(x=777, y=528, anchor='center')
A14_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(14)], bg = "light grey", variable = test_occupy[14])
A14_btn.place(x=733, y=528, anchor='center')

A20_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(20)], bg = "light grey", variable = test_occupy[20])
A20_btn.place(x=779, y=476, anchor='center')
A21_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(21)], bg = "light grey", variable = test_occupy[21])
A21_btn.place(x=823, y=476, anchor='center')
A22_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(22)], bg = "light grey", variable = test_occupy[22])
A22_btn.place(x=931, y=330, anchor='center')
A23_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(23)], bg = "light grey", variable = test_occupy[23])
A23_btn.place(x=911, y=169, anchor='center')
A24_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(24)], bg = "light grey", variable = test_occupy[24])
A24_btn.place(x=865, y=140, anchor='center')
A25_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(25)], bg = "light grey", variable = test_occupy[25])
A25_btn.place(x=686, y=140, anchor='center')
A26_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(26)], bg = "light grey", variable = test_occupy[26])
A26_btn.place(x=642, y=140, anchor='center')
A27_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(27)], bg = "light grey", variable = test_occupy[27])
A27_btn.place(x=363, y=281, anchor='center')
A28_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(28)], bg = "light grey", variable = test_occupy[28])
A28_btn.place(x=363, y=327, anchor='center')
A29_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(29)], bg = "light grey", variable = test_occupy[29])
A29_btn.place(x=442, y=476, anchor='center')
A30_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(30)], bg = "light grey", variable = test_occupy[30])
A30_btn.place(x=472, y=476, anchor='center')

A40_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(40)], bg = "light grey", variable = test_occupy[40])
A40_btn.place(x=436, y=501, anchor='center')
A41_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(41)], bg = "light grey", variable = test_occupy[41])
A41_btn.place(x=858, y=501, anchor='center')

A50_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(50)], bg = "light grey", variable = test_occupy[50])
A50_btn.place(x=646, y=528, anchor='center')
A51_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(51)], bg = "light grey", variable = test_occupy[51])
A51_btn.place(x=646, y=476, anchor='center')
A52_btn = Checkbutton(GUI, text = "", command = lambda:[read_axle_counters(52)], bg = "light grey", variable = test_occupy[52])
A52_btn.place(x=757, y=140, anchor='center')

    ###### Define key button functions #####

def call_point(point, status, manual):
    control = [None, w1.set, w2.set]
    if (point == 1 and TSL[2] == "clear" and TSL[11] == "clear") or (point == 2 and TSL[0] == "clear" and TSL[15] == "clear"):
        global PSL
        PSL[point] = status
        global pi_loaded
        cv.delete(pi_loaded[point])
        if status =="R":
            control[point](1)
            pi_loaded[point] = cv.create_image(0, 0, image = point_img[point][1], anchor='nw')
        else:
            control[point](0)
            pi_loaded[point] = cv.create_image(0, 0, image = point_img[point][0], anchor='nw')
        print(PSL[point])
        reset("signals")
        return 1
    else:
        if manual == 1 and point == 1 and w1.get() == 1: control[1](0)
        elif manual == 1 and point == 1 and w1.get() == 0: control[1](1)
        elif manual == 1 and point == 2 and w2.get() == 1: control[2](0)
        elif manual == 1 and point == 2 and w2.get() == 0: control[2](1)
        elif manual == 1: print("Denied")
        return 0

########### /Create GUI Window ###########

    
########### Track Section Display Functions ###########
def occupy(occupy):
    if occupy == "A1A": track = 0
    if occupy == "A2A": track = 1
    if occupy == "A1B": track = 2
    if occupy == "A2B": track = 3
    if occupy == "A3B": track = 4
    if occupy == "AC": track = 5
    if occupy == "AD": track = 6
    if occupy == "A1E": track = 7
    if occupy == "A2E": track = 8
    if occupy == "A3E": track = 9
    if occupy == "BA": track = 10
    if occupy == "BB": track = 11
    if occupy == "BC": track = 12
    if occupy == "BD": track = 13
    if occupy == "B1E": track = 14
    if occupy == "B2E": track = 15
    if TSL[track] == "clear": trackFX[track]("occ")
    else: trackFX[track]("clear")
    if track > 9: direction = 2
    else: direction = 1
    reset("signals")

def A1A_sta(status):
    global TSL
    TSL[0] = (status)
    x=0
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')
    global pi_loaded
    cv.delete(pi_loaded[2])
    pi_loaded[2] = cv.create_image(0, 0, image = point_img[2][w2.get()], anchor='nw')
    
def A2A_sta(status):
    global TSL
    TSL[1] = (status)
    x=1
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def A1B_sta(status):
    global TSL
    TSL[2] = (status)
    x=2
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')
    global pi_loaded
    cv.delete(pi_loaded[1])
    pi_loaded[1] = cv.create_image(0, 0, image = point_img[1][w1.get()], anchor='nw')

def A2B_sta(status):
    global TSL
    TSL[3] = (status)
    x=3
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def A3B_sta(status):
    global TSL
    TSL[4] = (status)
    x=4
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def AC_sta(status):
    global TSL
    TSL[5] = (status)
    x=5
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')
        
def AD_sta(status):
    global TSL
    TSL[6] = (status)
    x=6
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def A1E_sta(status):
    global TSL
    TSL[7] = (status)
    x=7
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def A3E_sta(status):
    global TSL
    TSL[9] = (status)
    x=9
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def A2E_sta(status):
    global TSL
    TSL[8] = (status)
    x=8
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def BA_sta(status):
    global TSL
    TSL[10] = (status)
    x=10
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def BB_sta(status):
    global TSL
    TSL[11] = (status)
    x=11
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')
    global pi_loaded
    cv.delete(pi_loaded[1])
    pi_loaded[1] = cv.create_image(0, 0, image = point_img[1][w1.get()], anchor='nw')

def BC_sta(status):
    global TSL
    TSL[12] = (status)
    x=12
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def BD_sta(status):
    global TSL
    TSL[13] = (status)
    x=13
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def B1E_sta(status):
    global TSL
    TSL[14] = (status)
    x=14
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')

def B2E_sta(status):
    global TSL
    TSL[15] = (status)
    x=15
    global ti_loaded
    cv.delete(ti_loaded[x])
    if (status) == "clear":
        cv.delete(ti_loaded[x])
    elif (status) == "blue":
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][1], anchor='nw')
    else:
        ti_loaded[x] = cv.create_image(0, 0, image = track_img[x][0], anchor='nw')
    global pi_loaded
    cv.delete(pi_loaded[2])
    pi_loaded[2] = cv.create_image(0, 0, image = point_img[2][w2.get()], anchor='nw')

########### /Track Section Display Functions ###########

########### Signal Display Functions ###########

def S1(signal):
    x=1
    global si_loaded
    cv.delete(si_loaded[x])
    if (signal) == "green":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][2], anchor='nw')
    elif (signal) == "yellow":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][1], anchor='nw')
    else:
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][0], anchor='nw')

def S3(signal):
    x=3
    global si_loaded
    cv.delete(si_loaded[x])
    if (signal) == "green":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][2], anchor='nw')
    elif (signal) == "yellow":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][1], anchor='nw')
    else:
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][0], anchor='nw')

def S5(signal):
    x=5
    global si_loaded
    cv.delete(si_loaded[x])
    if (signal) == "green":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][2], anchor='nw')
    elif (signal) == "yellow":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][1], anchor='nw')
    else:
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][0], anchor='nw')

def S7(signal):
    x=7
    global si_loaded
    cv.delete(si_loaded[x])
    if (signal) == "green":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][2], anchor='nw')
    elif (signal) == "yellow":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][1], anchor='nw')
    else:
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][0], anchor='nw')

def S2(signal):
    x=2
    global si_loaded
    cv.delete(si_loaded[x])
    if (signal) == "green":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][2], anchor='nw')
    elif (signal) == "yellow":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][1], anchor='nw')
    else:
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][0], anchor='nw')

def S4(signal):
    x=4
    global si_loaded
    cv.delete(si_loaded[x])
    if (signal) == "green":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][2], anchor='nw')
    elif (signal) == "yellow":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][1], anchor='nw')
    else:
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][0], anchor='nw')

def S6(signal):
    x=6
    global si_loaded
    cv.delete(si_loaded[x])
    if (signal) == "green":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][2], anchor='nw')
    elif (signal) == "yellow":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][1], anchor='nw')
    else:
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][0], anchor='nw')

def S8(signal):
    x=8
    global si_loaded
    cv.delete(si_loaded[x])
    if (signal) == "green":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][2], anchor='nw')
    elif (signal) == "yellow":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][1], anchor='nw')
    else:
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][0], anchor='nw')

def S10(signal):
    x=10
    global si_loaded
    cv.delete(si_loaded[x])
    if (signal) == "green":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][2], anchor='nw')
    elif (signal) == "yellow":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][1], anchor='nw')
    else:
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][0], anchor='nw')

def S12(signal):
    x=12
    global si_loaded
    cv.delete(si_loaded[x])
    if (signal) == "green":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][2], anchor='nw')
    elif (signal) == "yellow":
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][1], anchor='nw')
    else:
        si_loaded[x] = cv.create_image(0, 0, image = sig_img[x][0], anchor='nw')

########### /Signal Display Functions ###########


########### Core Signal and Track Status Handler ########### 
def reset(selection):
    if selection == "all":
        A1A_sta("clear")
        A2A_sta("clear")
        A1B_sta("clear")
        A2B_sta("clear")
        A3B_sta("clear")
        AC_sta("clear")
        AD_sta("clear")
        A1E_sta("clear")
        A2E_sta("clear")
        A3E_sta("clear")
        BA_sta("clear")
        BB_sta("clear")
        BC_sta("clear")
        BD_sta("clear")
        B1E_sta("clear")
        B2E_sta("clear")

    if selection == "signals" or selection == "all" or selection == "routes":
        signalFX = [None,S1,S2,S3,S4,S5,S6,S7,S8,None,S10,None,S12]
        signal = 1
        while signal < 13:
            if signalFX[signal] != None:
                if SSL[signal] == "green":
                    signalFX[signal]("green")
                elif SSL[signal] == "yellow":
                    signalFX[signal]("yellow")
                else:
                    signalFX[signal]("red")
            signal += 1

    if selection == "all":
        global last_AC
        n=0
        for x in test_occupy:
            test_occupy[n].set(False)
            n+=1
        last_AC = [1]*55
########### /Core Signal and Track Status Handler ########### 


######------------------------- MAIN CODE -------------------------#####

    # Initialise all track sections, signals, and points
reset("all")
trackFX = [A1A_sta,A2A_sta,A1B_sta,A2B_sta,A3B_sta,AC_sta,AD_sta,A1E_sta,A2E_sta,A3E_sta,BA_sta,BB_sta,BC_sta,BD_sta,B1E_sta,B2E_sta]

    ########### INITIALISE TELNET SERVER ###########

HOST = "localhost" #IP address of the SSI
control(SSL)
print("Initialising Telnet...")
print()
tn = telnetlib.Telnet(HOST, 7777)
time.sleep(1)
msg_in = tn.read_very_eager().decode('ascii')
print(msg_in)
tn.write(("FEP SIM\n").encode('ascii'))
read_msg(msg_in)
send_occupation()

    ########### /INITIALISE TELNET SERVER ###########

def cycle(): #Refresh telnet server
    msg_in = tn.read_very_eager().decode('ascii')
    if msg_in != "":
        print(msg_in)
        read_msg(msg_in)
    #send_occupation() #To be enabled once axle counters are installed.
    GUI.after(50, cycle)       # reschedule event in half-second

GUI.after(500, cycle)
GUI.mainloop()
#tn.close
